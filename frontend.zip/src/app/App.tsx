import { useState, useRef } from 'react';
import { Upload, Loader2, Info } from 'lucide-react';

type Ratio = '1:1' | '4:5' | '9:16';

export default function App() {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [rows, setRows] = useState<number>(3);
  const [cols, setCols] = useState<number>(3);
  const [ratio, setRatio] = useState<Ratio>('9:16');
  const [padding, setPadding] = useState<number>(0);
  const [verticalPadding, setVerticalPadding] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateGrid = async () => {
    if (!imageFile) {
      alert('Please upload an image first');
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append('file', imageFile);
    formData.append('rows', rows.toString());
    formData.append('cols', cols.toString());
    formData.append('ratio', ratio);
    formData.append('padding', padding.toString());

    try {
      const response = await fetch('http://127.0.0.1:8000/process', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to process image');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'instagram-grid.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to generate grid. Make sure the backend server is running.');
    } finally {
      setLoading(false);
    }
  };

  const renderGridOverlay = () => {
    if (!imagePreview) return null;

    const tiles: number[] = [];
    for (let i = 0; i < rows * cols; i++) {
      tiles.push(i + 1);
    }

    return (
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="grid h-full w-full"
          style={{
            gridTemplateRows: `repeat(${rows}, 1fr)`,
            gridTemplateColumns: `repeat(${cols}, 1fr)`,
            gap: '0',
          }}
        >
          {tiles.map((num, idx) => (
            <div
              key={idx}
              className="border border-blue-500/60 flex items-center justify-center relative"
            >
              {/* Show vertical padding indicator for 9:16 ratio */}
              {ratio === '9:16' && verticalPadding && (
                <>
                  <div className="absolute top-0 left-0 right-0 h-[20%] bg-white/20 border-b-2 border-dashed border-yellow-400/60"></div>
                  <div className="absolute bottom-0 left-0 right-0 h-[20%] bg-white/20 border-t-2 border-dashed border-yellow-400/60"></div>
                </>
              )}
              <span className="text-white text-xl font-bold bg-blue-500/80 px-2 py-1 rounded z-10">
                {num}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white dark">
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Instagram Grid Slicer
          </h1>
          <p className="text-gray-400">Split your 3:4 images into 9:16 story tiles with centered content</p>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-900/30 border border-blue-500/50 rounded-xl p-4 mb-8 flex items-start gap-3">
          <Info className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-200">
            <strong>How it works:</strong> Upload your 3:4 image, it will be sliced into a {rows}x{cols} grid. 
            Each tile will be in 9:16 ratio with your original image centered vertically. 
            White padding will be added to top and bottom only (no left/right padding).
          </div>
        </div>

        {/* Main Container */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl shadow-2xl p-8 border border-gray-700">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Left Side - Controls */}
            <div className="space-y-6">
              {/* File Upload */}
              <div>
                <label className="block text-sm font-medium mb-3 text-gray-300">
                  Upload Image (3:4 recommended)
                </label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-gray-600 rounded-xl p-8 text-center cursor-pointer hover:border-purple-500 hover:bg-gray-800/50 transition-all duration-300"
                >
                  <Upload className="mx-auto h-12 w-12 text-gray-500 mb-3" />
                  <p className="text-gray-400">
                    {imageFile ? imageFile.name : 'Click to upload a 3:4 image'}
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Grid Controls */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">
                    Rows
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={rows}
                    onChange={(e) => setRows(Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">
                    Columns
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={cols}
                    onChange={(e) => setCols(Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  />
                </div>
              </div>

              {/* Ratio Selector */}
              <div>
                <label className="block text-sm font-medium mb-3 text-gray-300">
                  Output Tile Aspect Ratio
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['1:1', '4:5', '9:16'] as Ratio[]).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRatio(r)}
                      className={`py-3 px-4 rounded-lg font-medium transition-all duration-300 ${
                        ratio === r
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/50'
                          : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700'
                      }`}
                    >
                      {r}
                      {r === '9:16' && (
                        <div className="text-xs mt-1 opacity-80">Story</div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Padding Options */}
              <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">
                    Padding: {padding}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={padding}
                    onChange={(e) => setPadding(Number(e.target.value))}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                    style={{
                      background: `linear-gradient(to right, rgb(168 85 247) 0%, rgb(168 85 247) ${padding * 10}%, rgb(55 65 81) ${padding * 10}%, rgb(55 65 81) 100%)`,
                    }}
                  />
                </div>

                {/* Vertical Padding Only Toggle */}
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">
                    Vertical Padding Only (Top/Bottom)
                  </label>
                  <button
                    onClick={() => setVerticalPadding(!verticalPadding)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      verticalPadding ? 'bg-purple-500' : 'bg-gray-600'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        verticalPadding ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {verticalPadding && ratio === '9:16' && (
                  <div className="text-xs text-yellow-400 flex items-start gap-2">
                    <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>
                      Your 3:4 image will be centered vertically in each 9:16 tile with white padding on top/bottom. No left/right padding.
                    </span>
                  </div>
                )}
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateGrid}
                disabled={!imageFile || loading}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 rounded-xl font-semibold hover:shadow-xl hover:shadow-purple-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Generate Grid'
                )}
              </button>
            </div>

            {/* Right Side - Preview */}
            <div>
              <label className="block text-sm font-medium mb-3 text-gray-300">
                Preview
              </label>
              <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden aspect-[3/4] flex items-center justify-center">
                {imagePreview ? (
                  <div className="relative w-full h-full">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-contain"
                    />
                    {renderGridOverlay()}
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <Upload className="mx-auto h-16 w-16 mb-4 opacity-50" />
                    <p>Upload a 3:4 image to see preview</p>
                  </div>
                )}
              </div>
              
              {ratio === '9:16' && verticalPadding && imagePreview && (
                <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-500/30 rounded-lg text-xs text-yellow-200">
                  <strong>Preview Note:</strong> Yellow dashed lines show where white padding will be added (top ~20% and bottom ~20% of each tile)
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        input[type="range"]::-webkit-slider-thumb {
          appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: white;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }
        input[type="range"]::-moz-range-thumb {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: white;
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }
      `}</style>
    </div>
  );
}