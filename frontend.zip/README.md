
  # Generate Frontend

  This is a code bundle for Generate Frontend. The original project is available at https://www.figma.com/design/QfHxAlxtWUbOriMjTjHTTs/Generate-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  